<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AIVision_Admin {

    public static function init() {
        add_action( 'admin_menu',            [ __CLASS__, 'register_menu' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
        add_action( 'wp_ajax_aivision_save_settings', [ __CLASS__, 'ajax_save_settings' ] );
        add_action( 'wp_ajax_aivision_robots_preview', [ __CLASS__, 'ajax_robots_preview' ] );
        add_action( 'wp_ajax_aivision_auto_optimize_robots', [ __CLASS__, 'ajax_auto_optimize_robots' ] );
        add_action( 'wp_ajax_aivision_generate_sitemap', [ __CLASS__, 'ajax_generate_sitemap' ] );
        add_action( 'wp_ajax_aivision_generate_llmstxt', [ __CLASS__, 'ajax_generate_llmstxt' ] );
        add_action( 'wp_ajax_aivision_generate_llmstxt_full', [ __CLASS__, 'ajax_generate_llmstxt_full' ] );

        // Add SEO, AEO, and GEO score columns to standard Posts and Pages list tables
        add_filter( 'manage_posts_columns',       [ __CLASS__, 'add_posts_columns' ] );
        add_action( 'manage_posts_custom_column', [ __CLASS__, 'render_posts_columns' ], 10, 2 );
        add_filter( 'manage_pages_columns',       [ __CLASS__, 'add_posts_columns' ] );
        add_action( 'manage_pages_custom_column', [ __CLASS__, 'render_posts_columns' ], 10, 2 );
    }

    public static function register_menu() {
        add_menu_page(
            'AIVision SEO',
            'AIVision SEO',
            'manage_options',
            'aivision-seo',
            [ __CLASS__, 'page_dashboard' ],
            'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><circle cx="10" cy="10" r="8" fill="none" stroke="#fff" stroke-width="1.5"/><path d="M6 14l2-4 2 2 2-5 2 3" stroke="#fff" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/><circle cx="10" cy="4" r="1.5" fill="#fff"/></svg>'),
            80
        );
        add_submenu_page( 'aivision-seo', 'Dashboard',        'Dashboard',        'manage_options', 'aivision-seo',           [ __CLASS__, 'page_dashboard' ] );
        add_submenu_page( 'aivision-seo', 'AI Crawlers',      'AI Crawlers',      'manage_options', 'aivision-robots',         [ __CLASS__, 'page_robots' ] );
        add_submenu_page( 'aivision-seo', 'Settings',         'Settings',         'manage_options', 'aivision-settings-page',  [ __CLASS__, 'page_settings' ] );
    }

    public static function enqueue( $hook ) {
        $pages = [ 'toplevel_page_aivision-seo', 'aivision-seo_page_aivision-robots', 'aivision-seo_page_aivision-settings-page' ];
        $is_meta = in_array( $hook, [ 'post.php', 'post-new.php', 'edit.php' ] );
        if ( ! in_array( $hook, $pages ) && ! $is_meta ) return;

        wp_enqueue_style(  'aivision-admin-v140', AIVISION_URL . 'admin/css/admin.css', [], AIVISION_VERSION );
        if ( $hook !== 'edit.php' ) {
            wp_enqueue_script( 'aivision-admin-v140', AIVISION_URL . 'admin/js/admin.js',  [ 'jquery', 'wp-util' ], AIVISION_VERSION, true );
            wp_localize_script( 'aivision-admin-v140', 'aiVision', [
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'aivision_nonce' ),
                'schema_templates' => AIVision_Schema::templates(),
            ] );
        }
    }

    public static function add_posts_columns( $columns ) {
        $columns['aivision_seo'] = 'SEO';
        $columns['aivision_aeo'] = 'AEO';
        $columns['aivision_geo'] = 'GEO';
        return $columns;
    }

    public static function render_posts_columns( $column, $post_id ) {
        $meta = get_post_meta( $post_id, AIVISION_META_KEY, true ) ?: [];
        if ( $column === 'aivision_seo' ) {
            $seo = AIVision_Analyzer::seo_score( $post_id, $meta );
            echo '<span class="aivision-score-badge" style="background:' . esc_attr( $seo['grade']['color'] ) . '; font-size: 11px; padding: 2px 7px;">' . esc_html( $seo['score'] ) . '%</span>';
        } elseif ( $column === 'aivision_aeo' ) {
            $aeo = AIVision_Analyzer::aeo_score( $post_id, $meta );
            echo '<span class="aivision-score-badge" style="background:' . esc_attr( $aeo['grade']['color'] ) . '; font-size: 11px; padding: 2px 7px;">' . esc_html( $aeo['score'] ) . '%</span>';
        } elseif ( $column === 'aivision_geo' ) {
            $geo = AIVision_Analyzer::geo_score( $post_id, $meta );
            echo '<span class="aivision-score-badge" style="background:' . esc_attr( $geo['grade']['color'] ) . '; font-size: 11px; padding: 2px 7px;">' . esc_html( $geo['score'] ) . '%</span>';
        }
    }

    // ── Dashboard ─────────────────────────────────────────────────────────────
    public static function page_dashboard() {
        global $wpdb;

        // Stats: posts with meta
        $posts_with_meta = $wpdb->get_var(
            $wpdb->prepare( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = %s", AIVISION_META_KEY )
        );
        $post_counts = wp_count_posts( 'post' );
        $page_counts = wp_count_posts( 'page' );
        $total_posts = ( (int) ( $post_counts->publish ?? 0 ) ) + ( (int) ( $page_counts->publish ?? 0 ) );

        // Recent posts scores
        $recent = get_posts( [ 'numberposts' => 8, 'post_status' => 'publish', 'post_type' => [ 'post', 'page' ] ] );
        $recent_data = [];
        foreach ( $recent as $p ) {
            $meta = get_post_meta( $p->ID, AIVISION_META_KEY, true ) ?: [];
            $seo  = AIVision_Analyzer::seo_score( $p->ID, $meta );
            $aeo  = AIVision_Analyzer::aeo_score( $p->ID, $meta );
            $geo  = AIVision_Analyzer::geo_score( $p->ID, $meta );
            $recent_data[] = [
                'post'    => $p,
                'seo'     => $seo,
                'aeo'     => $aeo,
                'geo'     => $geo,
                'meta'    => $meta,
            ];
        }

        // Settings
        $settings = get_option( 'aivision_settings', [] );
        $ai_bots_count = count( array_filter( AIVision_Robots::ALL_BOTS, fn($b) => $b['type'] === 'ai' ) );
        $allowed_count = count( array_intersect( $settings['allowed_bots'] ?? AIVision_Robots::OPTIMAL_ALLOWED_BOTS, array_keys( AIVision_Robots::ALL_BOTS ) ) );
        ?>
        <div class="aivision-wrap">
            <div class="aivision-header">
                <div class="aivision-logo">
                    <span class="aivision-logo-icon">🎯</span>
                    <div>
                        <h1>AIVision SEO, AEO &amp; GEO Engine</h1>
                        <p>Real-time optimization for Search Engines, Answer Engines &amp; Generative AI</p>
                    </div>
                </div>
                <div class="aivision-header-stats">
                    <div class="aivision-stat-pill">
                        <span class="aivision-stat-val"><?php echo esc_html($posts_with_meta); ?>/<?php echo esc_html($total_posts); ?></span>
                        <span class="aivision-stat-lbl">Optimized Content</span>
                    </div>
                    <div class="aivision-stat-pill">
                        <span class="aivision-stat-val"><?php echo esc_html($allowed_count); ?>/<?php echo esc_html($ai_bots_count); ?></span>
                        <span class="aivision-stat-lbl">AI Crawlers Allowed</span>
                    </div>
                </div>
            </div>

            <div class="aivision-tab-panel" id="av-panel-overview">
                <!-- 3 Pillars Feature Cards -->
                <div class="aivision-grid-3">
                    <div class="aivision-card aivision-feature-card">
                        <div class="aivision-card-icon" style="background:#e0f2fe; color:#0284c7;">📊</div>
                        <h3>1. Search Engines (SEO)</h3>
                        <p>Classic on-page optimization for Google &amp; Bing: titles, meta descriptions, keyword density, headings, and internal linking.</p>
                    </div>
                    <div class="aivision-card aivision-feature-card">
                        <div class="aivision-card-icon" style="background:#fef3c7; color:#d97706;">💬</div>
                        <h3>2. Answer Engines (AEO)</h3>
                        <p>Structured Q&amp;A blocks, direct snippet-bait paragraphs, numbered steps, and FAQPage schemas to win Google Featured Snippets &amp; AI Overviews.</p>
                    </div>
                    <div class="aivision-card aivision-feature-card">
                        <div class="aivision-card-icon" style="background:#ede9fe; color:#7c3aed;">🤖</div>
                        <h3>3. Generative Engines (GEO)</h3>
                        <p>High data density, external authoritative citations, E-E-A-T credentials, /llms.txt machine feeds, and open AI crawler access for ChatGPT, Claude, and Perplexity.</p>
                    </div>
                </div>

                <!-- Recent Posts Table -->
                <div class="aivision-card" style="margin-top:20px">
                    <div class="aivision-card-header">
                        <h2>Recent Content Optimization</h2>
                    </div>
                    <table class="aivision-table">
                        <thead>
                            <tr>
                                <th>Content Title</th>
                                <th>SEO</th>
                                <th>AEO</th>
                                <th>GEO</th>
                                <th>Schemas</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $recent_data as $item ) :
                                $p   = $item['post'];
                                $seo = $item['seo'];
                                $aeo = $item['aeo'];
                                $geo = $item['geo'];
                                $sc  = count( $item['meta']['schemas'] ?? [] );
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html( $p->post_title ); ?></strong>
                                    <div class="aivision-meta-url"><?php echo esc_url( get_permalink($p->ID) ); ?></div>
                                </td>
                                <td><span class="aivision-score-badge" style="background:<?php echo esc_attr($seo['grade']['color']); ?>"><?php echo esc_html($seo['score']); ?>%</span></td>
                                <td><span class="aivision-score-badge" style="background:<?php echo esc_attr($aeo['grade']['color']); ?>"><?php echo esc_html($aeo['score']); ?>%</span></td>
                                <td><span class="aivision-score-badge" style="background:<?php echo esc_attr($geo['grade']['color']); ?>"><?php echo esc_html($geo['score']); ?>%</span></td>
                                <td><?php echo $sc > 0 ? '<span class="aivision-badge aivision-badge-green">' . esc_html($sc) . ' schema' . ($sc > 1 ? 's' : '') . '</span>' : '<span class="aivision-badge aivision-badge-gray">None</span>'; ?></td>
                                <td><a href="<?php echo esc_url( get_edit_post_link($p->ID) ); ?>" class="aivision-btn aivision-btn-sm">Edit &amp; Optimize</a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- GEO & AEO Tips -->
                <div class="aivision-card aivision-card-tips">
                    <div class="aivision-card-header"><h2>💡 Key AEO &amp; GEO Optimization Guidelines</h2></div>
                    <div class="aivision-tips-grid">
                        <?php foreach ( self::geo_tips() as $tip ) : ?>
                        <div class="aivision-tip">
                            <div class="aivision-tip-icon"><?php echo $tip['icon']; ?></div>
                            <div>
                                <strong><?php echo esc_html($tip['title']); ?></strong>
                                <p><?php echo esc_html($tip['desc']); ?></p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    // ── AI Crawlers / Robots Page ─────────────────────────────────────────────
    public static function page_robots() {
        $settings = get_option( 'aivision_settings', [] );
        $allowed  = $settings['allowed_bots'] ?? AIVision_Robots::OPTIMAL_ALLOWED_BOTS;
        ?>
        <div class="aivision-wrap">
            <div class="aivision-header">
                <div class="aivision-logo"><span class="aivision-logo-icon">🤖</span><div><h1>AI Crawler &amp; Robots Manager</h1><p>Control crawler access and auto-optimize your robots.txt file</p></div></div>
                <button type="button" class="aivision-btn aivision-btn-primary" id="av-auto-optimize-robots-btn" style="background:#4f46e5; border-color:#4338ca;">⚡ Auto-Optimize robots.txt (1-Click)</button>
            </div>
            <div class="aivision-two-col">
                <div class="aivision-card" style="flex:2">
                    <div class="aivision-card-header"><h2>Bot Access Control</h2></div>
                    <div class="aivision-bot-section-label">🔍 Search Engines</div>
                    <?php self::render_bot_list( 'search', $allowed ); ?>
                    <div class="aivision-bot-section-label" style="margin-top:16px">🤖 AI / LLM Crawlers</div>
                    <?php self::render_bot_list( 'ai', $allowed ); ?>
                    <div class="aivision-bot-section-label" style="margin-top:16px">📣 Social Crawlers</div>
                    <?php self::render_bot_list( 'social', $allowed ); ?>
                    <div style="margin-top:20px; display:flex; gap:10px;">
                        <button type="button" class="aivision-btn aivision-btn-primary" id="av-save-bots" data-action="aivision_save_settings">Save Bot Settings</button>
                    </div>
                </div>
                <div class="aivision-card">
                    <div class="aivision-card-header"><h2>robots.txt Preview</h2><button type="button" class="aivision-btn aivision-btn-sm" id="av-refresh-robots">Refresh</button></div>
                    <pre id="av-robots-preview" class="aivision-code" style="white-space:pre-wrap;font-size:12px;min-height:320px">Loading...</pre>
                    <p style="margin-top:8px;font-size:12px;color:#666">Live preview of your robots.txt served to search &amp; AI crawlers. <a href="<?php echo esc_url( home_url('/robots.txt') ); ?>" target="_blank">View live →</a></p>
                </div>
            </div>
        </div>
        <?php
    }

    private static function render_bot_list( $type, $allowed ) {
        foreach ( AIVision_Robots::ALL_BOTS as $bot => $info ) {
            if ( $info['type'] !== $type ) continue;
            $checked = in_array( $bot, $allowed, true );
            ?>
            <div class="aivision-bot-row">
                <label class="aivision-toggle">
                    <input type="checkbox" name="allowed_bots[]" value="<?php echo esc_attr($bot); ?>" <?php checked($checked); ?>>
                    <span class="aivision-toggle-slider"></span>
                </label>
                <div class="aivision-bot-info">
                    <strong><?php echo esc_html($info['name']); ?></strong>
                    <code><?php echo esc_html($bot); ?></code>
                </div>
                <span class="aivision-badge aivision-badge-<?php echo $checked ? 'green' : 'red'; ?>"><?php echo $checked ? 'Allowed' : 'Blocked'; ?></span>
            </div>
            <?php
        }
    }

    // ── Settings Page ─────────────────────────────────────────────────────────
    public static function page_settings() {
        $settings  = get_option( 'aivision_settings', [] );
        $site_type = $settings['site_type'] ?? 'general';
        $site_ai_bio = $settings['site_ai_bio'] ?? '';
        ?>
        <div class="aivision-wrap">
            <div class="aivision-header">
                <div class="aivision-logo"><span class="aivision-logo-icon">⚙️</span><div><h1>Settings</h1><p>Configure AIVision SEO, AEO &amp; GEO parameters</p></div></div>
            </div>
            <div class="aivision-card">
                <div class="aivision-card-header"><h2>General Settings</h2></div>
                <form id="av-settings-form">
                    <div class="aivision-form-group">
                        <label>Site Type / Niche</label>
                        <select name="site_type">
                            <option value="general"   <?php selected($site_type,'general'); ?>>General / Blog</option>
                            <option value="medical"   <?php selected($site_type,'medical'); ?>>Medical / Dental</option>
                            <option value="ecommerce" <?php selected($site_type,'ecommerce'); ?>>E-Commerce</option>
                            <option value="local"     <?php selected($site_type,'local'); ?>>Local Business</option>
                            <option value="news"      <?php selected($site_type,'news'); ?>>News / Magazine</option>
                        </select>
                        <p class="aivision-hint">Affects which schema types and keyword suggestions are prioritized.</p>
                    </div>

                    <div class="aivision-form-group">
                        <label for="av-site-ai-bio">Site AI Bio &amp; Context (Injected into /llms.txt)</label>
                        <textarea name="site_ai_bio" id="av-site-ai-bio" rows="3" placeholder="e.g. Leading dental clinic in Tirana specializing in all-on-4 dental implants, aesthetic prosthetics, and patient-centered dental tourism since 2012."><?php echo esc_textarea($site_ai_bio); ?></textarea>
                        <p class="aivision-hint">This description is placed at the top of your <code>/llms.txt</code> feed to define your organization's background, authority, and tone for AI models (ChatGPT, Claude, Perplexity).</p>
                    </div>

                    <div class="aivision-form-group">
                        <label>Default Robots Directive</label>
                        <select name="default_robots">
                            <option value="index, follow"     <?php selected($settings['default_robots'] ?? '', 'index, follow'); ?>>index, follow</option>
                            <option value="noindex, follow"   <?php selected($settings['default_robots'] ?? '', 'noindex, follow'); ?>>noindex, follow</option>
                            <option value="index, nofollow"   <?php selected($settings['default_robots'] ?? '', 'index, nofollow'); ?>>index, nofollow</option>
                            <option value="noindex, nofollow" <?php selected($settings['default_robots'] ?? '', 'noindex, nofollow'); ?>>noindex, nofollow</option>
                        </select>
                    </div>

                    <div class="aivision-form-group">
                        <label class="aivision-checkbox-label">
                            <input type="checkbox" name="ai_crawlers_enabled" value="1" <?php checked( ! empty($settings['ai_crawlers_enabled']) ); ?>>
                            Enable AI crawler directives in robots.txt
                        </label>
                        <p class="aivision-hint">Adds explicit Allow/Disallow rules for AI bots to your robots.txt file.</p>
                    </div>

                    <div class="aivision-form-group">
                        <label class="aivision-checkbox-label">
                            <input type="checkbox" name="remove_default_generator" value="1" <?php checked( ! empty($settings['remove_default_generator']) ); ?>>
                            Remove WordPress generator meta tag
                        </label>
                        <p class="aivision-hint">Hides your WordPress version from <code>&lt;meta name="generator"&gt;</code>.</p>
                    </div>

                    <div style="display:flex; gap:10px; align-items:center; margin-top:20px;">
                        <button type="submit" class="aivision-btn aivision-btn-primary">Save Settings</button>
                        <button type="button" class="aivision-btn aivision-btn-secondary" id="av-auto-optimize-robots-btn">⚡ Auto-Optimize robots.txt</button>
                    </div>
                </form>
            </div>

            <!-- XML Sitemap Card -->
            <div class="aivision-card" style="margin-top:20px">
                <div class="aivision-card-header"><h2>🗺️ XML Sitemap</h2></div>
                <div class="aivision-form-group">
                    <p>AIVision SEO generates a fast dynamic sitemap feed at <code>/sitemap.xml</code> and can write a static physical copy to the web root.</p>
                    <div style="margin-top:15px; display:flex; align-items:center; gap:15px;">
                        <button type="button" class="aivision-btn aivision-btn-primary" id="av-generate-sitemap-btn">Generate Sitemap XML</button>
                        <a href="<?php echo esc_url( home_url('/sitemap.xml') ); ?>" target="_blank" class="aivision-link" id="av-sitemap-view-link">View /sitemap.xml →</a>
                    </div>
                    <div id="av-sitemap-status" style="margin-top:12px; display:none; padding:10px; border-radius:6px; font-size:13px;"></div>
                </div>
            </div>

            <!-- LLMs.txt Card -->
            <div class="aivision-card" style="margin-top:20px">
                <div class="aivision-card-header"><h2>📄 LLMs.txt &amp; LLMs-Full.txt (AI Discovery Feeds)</h2></div>
                <div class="aivision-form-group">
                    <p>Provide structured, high-context markdown feeds for Large Language Models (ChatGPT, Claude, Perplexity) adhering to the <a href="https://llmstxt.org/" target="_blank">llmstxt.org</a> standard.</p>
                    <div style="margin-top:15px; display:flex; align-items:center; gap:15px; flex-wrap:wrap;">
                        <button type="button" class="aivision-btn aivision-btn-primary" id="av-generate-llmstxt-btn">Generate LLMs.txt</button>
                        <button type="button" class="aivision-btn aivision-btn-secondary" id="av-generate-llmstxt-full-btn">Generate LLMs-Full.txt</button>
                        <a href="<?php echo esc_url( home_url('/llms.txt') ); ?>" target="_blank" class="aivision-link" id="av-llmstxt-view-link">View /llms.txt →</a>
                        <a href="<?php echo esc_url( home_url('/llms-full.txt') ); ?>" target="_blank" class="aivision-link" id="av-llmstxt-full-view-link">View /llms-full.txt →</a>
                    </div>
                    <div id="av-llmstxt-status" style="margin-top:12px; display:none; padding:10px; border-radius:6px; font-size:13px;"></div>
                </div>
            </div>
        </div>
        <?php
    }

    // ── AJAX: Save Settings ───────────────────────────────────────────────────
    public static function ajax_save_settings() {
        check_ajax_referer( 'aivision_nonce', 'nonce' );
        if ( ! current_user_can('manage_options') ) wp_send_json_error('Unauthorized');

        if ( function_exists( 'opcache_reset' ) ) {
            @opcache_reset();
        }

        $current = get_option( 'aivision_settings', [] );
        $post    = $_POST;

        if ( isset( $post['site_type'] ) ) {
            $current['site_type']      = sanitize_text_field( $post['site_type'] );
            $current['site_ai_bio']    = sanitize_textarea_field( $post['site_ai_bio'] ?? '' );
            $current['default_robots'] = sanitize_text_field( $post['default_robots'] ?? 'index, follow' );
            $current['remove_default_generator'] = ! empty( $post['remove_default_generator'] );
        }

        if ( isset( $post['ai_crawlers_enabled'] ) ) {
            $current['ai_crawlers_enabled'] = ! empty( $post['ai_crawlers_enabled'] );
        }

        $is_bot_settings = isset( $post['is_bot_settings'] ) || ! isset( $post['site_type'] );

        if ( $is_bot_settings ) {
            if ( isset( $post['allowed_bots'] ) && is_array( $post['allowed_bots'] ) ) {
                $all_bot_keys = array_keys( AIVision_Robots::ALL_BOTS );
                $current['allowed_bots'] = array_intersect( array_map('sanitize_text_field', $post['allowed_bots']), $all_bot_keys );
            } else {
                $current['allowed_bots'] = [];
            }
        }

        update_option( 'aivision_settings', $current );
        
        // Auto-sync robots and llms
        AIVision_Robots::write_physical_robots();
        AIVision_LLMsTxt::auto_sync();

        wp_send_json_success( [ 'message' => 'Settings saved and feeds synced.' ] );
    }

    // ── AJAX: Auto-Optimize robots.txt ────────────────────────────────────────
    public static function ajax_auto_optimize_robots() {
        check_ajax_referer( 'aivision_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $res = AIVision_Robots::apply_auto_optimize_preset();
        $preview = AIVision_Robots::get_robots_preview();

        wp_send_json_success([
            'message' => $res['message'],
            'preview' => $preview,
            'allowed_bots' => $res['allowed_bots']
        ]);
    }

    // ── AJAX: Robots Preview ──────────────────────────────────────────────────
    public static function ajax_robots_preview() {
        check_ajax_referer( 'aivision_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );
        wp_send_json_success( [ 'content' => AIVision_Robots::get_robots_preview() ] );
    }

    // ── AJAX: Generate Sitemap ────────────────────────────────────────────────
    public static function ajax_generate_sitemap() {
        check_ajax_referer( 'aivision_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $result = AIVision_Sitemap::write_physical_sitemap();

        if ( $result['success'] ) {
            wp_send_json_success( [
                'message' => 'Sitemap XML file successfully written to root directory!',
                'url'     => $result['url'],
                'physical'=> true
            ] );
        } else {
            flush_rewrite_rules();
            wp_send_json_success( [
                'message' => 'Dynamic sitemap registered (could not write to root directory: ' . $result['error'] . ').',
                'url'     => $result['url'],
                'physical'=> false
            ] );
        }
    }

    // ── AJAX: Generate LLMs.txt ───────────────────────────────────────────────
    public static function ajax_generate_llmstxt() {
        check_ajax_referer( 'aivision_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $result = AIVision_LLMsTxt::write_physical_file();

        if ( $result['success'] ) {
            wp_send_json_success( [
                'message' => 'llms.txt file successfully written to root directory!',
                'url'     => $result['url'],
                'physical'=> true
            ] );
        } else {
            flush_rewrite_rules();
            wp_send_json_success( [
                'message' => 'Dynamic llms.txt serving registered (could not write to root directory).',
                'url'     => $result['url'],
                'physical'=> false
            ] );
        }
    }

    // ── AJAX: Generate LLMs-Full.txt ──────────────────────────────────────────
    public static function ajax_generate_llmstxt_full() {
        check_ajax_referer( 'aivision_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $result = AIVision_LLMsTxt::write_physical_full_file();

        if ( $result['success'] ) {
            wp_send_json_success( [
                'message' => 'llms-full.txt file successfully written to root directory!',
                'url'     => $result['url'],
                'physical'=> true
            ] );
        } else {
            flush_rewrite_rules();
            wp_send_json_success( [
                'message' => 'Dynamic llms-full.txt serving registered.',
                'url'     => $result['url'],
                'physical'=> false
            ] );
        }
    }

    // ── Content helpers ───────────────────────────────────────────────────────
    private static function geo_tips() {
        return [
            [ 'icon' => '💬', 'title' => 'Answer Directly in 40–60 Words', 'desc' => 'Place a concise definition or direct answer immediately below question headings to win Featured Snippets & AI Overviews.' ],
            [ 'icon' => '🔢', 'title' => 'Include Statistics & Specific Figures', 'desc' => 'Articles containing concrete numbers, percentages (%), and dates get cited 3.5x more often by LLMs.' ],
            [ 'icon' => '📋', 'title' => 'Add FAQPage & Article Schemas', 'desc' => 'Structured JSON-LD allows search and AI engines to parse intent, entities, and Q&A pairs instantly.' ],
            [ 'icon' => '📊', 'title' => 'Use Tables & Ordered Steps',   'desc' => 'Structured <ol> and comparison tables provide tabular facts that LLMs extract for synthesized answers.' ],
            [ 'icon' => '👤', 'title' => 'Highlight E-E-A-T & First-Person Experience', 'desc' => 'Author credentials and first-person test indicators ("in our clinical findings...") prove human authority.' ],
            [ 'icon' => '🤖', 'title' => 'Keep AI Crawlers Allowed',    'desc' => 'Ensure GPTBot, ClaudeBot, PerplexityBot, and Applebot-Extended are permitted in your robots.txt.' ],
        ];
    }
}
